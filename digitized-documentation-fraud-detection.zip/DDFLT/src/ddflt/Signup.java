/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ddflt;

//import login.practice.Login;
import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class Signup extends javax.swing.JFrame {

    public Signup() {
        initComponents();
       // this.setResizable(false);
        setIcon();
    //    txtContact.setSize(4);
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnGenderGroup = new javax.swing.ButtonGroup();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtEmpid = new javax.swing.JTextField();
        txtUsername = new javax.swing.JTextField();
        txtPassword = new javax.swing.JPasswordField();
        SecQue1 = new javax.swing.JComboBox();
        SecQue2 = new javax.swing.JComboBox();
        txtSecQue1 = new javax.swing.JTextField();
        txtSecQue2 = new javax.swing.JTextField();
        Framebg = new javax.swing.JLabel();
        rbtMale = new javax.swing.JRadioButton();
        rbtFemale = new javax.swing.JRadioButton();
        btnSubmit = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txtContact = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAlwaysOnTop(true);
        setBounds(new java.awt.Rectangle(100, 100, 500, 500));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(null);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Username");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(20, 104, 60, 20);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Password");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(20, 140, 68, 21);
        getContentPane().add(txtEmpid);
        txtEmpid.setBounds(90, 60, 152, 30);

        txtUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUsernameActionPerformed(evt);
            }
        });
        getContentPane().add(txtUsername);
        txtUsername.setBounds(90, 100, 152, 30);
        getContentPane().add(txtPassword);
        txtPassword.setBounds(90, 140, 152, 30);

        SecQue1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        SecQue1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "---------------Security Question 1--------------------" }));
        getContentPane().add(SecQue1);
        SecQue1.setBounds(260, 60, 380, 30);

        SecQue2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        SecQue2.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "---------------Security Question 2--------------------" }));
        getContentPane().add(SecQue2);
        SecQue2.setBounds(260, 140, 380, 30);
        getContentPane().add(txtSecQue1);
        txtSecQue1.setBounds(261, 100, 330, 30);
        getContentPane().add(txtSecQue2);
        txtSecQue2.setBounds(261, 180, 330, 30);

        Framebg.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Framebg.setText("Gender");
        getContentPane().add(Framebg);
        Framebg.setBounds(20, 180, 44, 20);

        rbtMale.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        rbtMale.setText("Male");
        getContentPane().add(rbtMale);
        rbtMale.setBounds(90, 180, 70, 23);

        rbtFemale.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        rbtFemale.setText("Female");
        getContentPane().add(rbtFemale);
        rbtFemale.setBounds(160, 180, 66, 23);

        btnSubmit.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnSubmit.setText("Submit");
        btnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitActionPerformed(evt);
            }
        });
        btnSubmit.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                btnSubmitKeyTyped(evt);
            }
        });
        getContentPane().add(btnSubmit);
        btnSubmit.setBounds(140, 250, 85, 23);

        btnExit.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnExit.setText("Cancel");
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });
        getContentPane().add(btnExit);
        btnExit.setBounds(260, 250, 79, 23);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("Contact");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(20, 210, 53, 23);

        txtContact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContactActionPerformed(evt);
            }
        });
        txtContact.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtContactKeyTyped(evt);
            }
        });
        getContentPane().add(txtContact);
        txtContact.setBounds(90, 210, 152, 30);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("Emp_id");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(20, 60, 70, 30);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel4.setLabelFor(this);
        jLabel4.setText("Signup to DDF");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(150, 10, 380, 40);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ddflt/home-img-iso.jpg"))); // NOI18N
        jLabel6.setText("jLabel6");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(0, 0, 650, 330);
        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 640, 350);

        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(20, 64, 60, 20);

        jLabel7.setText("jLabel7");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(0, 0, 210, 120);

        pack();
    }// </editor-fold>//GEN-END:initComponents
public void clearAll(){
    txtEmpid.setText(null);
    txtUsername.setText(null);
    txtPassword.setText(null);
    txtSecQue1.setText(null);
    txtSecQue2.setText(null);
    txtContact.setText(null);  
   //rbtFemale.setSelected(true);
  // rbtMale.setSelected(true);
       
}
    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
       
    }//GEN-LAST:event_formWindowClosed

    private void txtUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsernameActionPerformed
      
    }//GEN-LAST:event_txtUsernameActionPerformed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnExitActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
       try{
    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
        Connection con=DriverManager.getConnection("jdbc:odbc:DDF","sa","rabindra");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("Select * from SecQue1");
            while(rs.next())
            {
                SecQue1.addItem(rs.getString("secQue1"));
                SecQue2.addItem(rs.getString("secQue2"));
}
}
catch(Exception e)
{
    e.printStackTrace();
}
    }//GEN-LAST:event_formWindowOpened

    private void btnSubmitKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnSubmitKeyTyped

    }//GEN-LAST:event_btnSubmitKeyTyped

    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmitActionPerformed
       try{
       Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
       Connection con=DriverManager.getConnection("jdbc:odbc:DDF","sa","rabindra");
       PreparedStatement pst=con.prepareStatement("insert into signup values('"+txtEmpid.getText()+"','"+txtUsername.getText()+"','"+txtPassword.getText()+"','"+txtContact.getText()+"','"+txtSecQue1.getName()+"','"+txtSecQue2.getText()+"')");
       pst.executeQuery();
       }
       catch(Exception e)
      {
      e.printStackTrace();
      }
    }//GEN-LAST:event_btnSubmitActionPerformed

    private void txtContactKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtContactKeyTyped
     char c=evt.getKeyChar();
       if(!Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE) || (c==KeyEvent.VK_DELETE)){
       evt.consume();
       }
    }//GEN-LAST:event_txtContactKeyTyped

    private void txtContactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContactActionPerformed
        int a;
        String s;
        s=readLine(txtContact.getText());
        a=Integer.parseInt(txtContact.getText());
        if(s.length()>10){
        JOptionPane.showMessageDialog(null,"Only 10 digits");
        txtContact.setText(null);
        }
    }//GEN-LAST:event_txtContactActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Signup().setVisible(true);
            new Signup().setLocation(250,300);
            new Signup().setSize(500,500);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Framebg;
    private javax.swing.JComboBox SecQue1;
    private javax.swing.JComboBox SecQue2;
    private javax.swing.JButton btnExit;
    private javax.swing.ButtonGroup btnGenderGroup;
    private javax.swing.JButton btnSubmit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton rbtFemale;
    private javax.swing.JRadioButton rbtMale;
    private javax.swing.JTextField txtContact;
    private javax.swing.JTextField txtEmpid;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtSecQue1;
    private javax.swing.JTextField txtSecQue2;
    private javax.swing.JTextField txtUsername;
    // End of variables declaration//GEN-END:variables

    private void setIcon() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("DDFicon.png")));
          this.setTitle("Digitized Fraud Detecetion(DFD)");
    }
}
