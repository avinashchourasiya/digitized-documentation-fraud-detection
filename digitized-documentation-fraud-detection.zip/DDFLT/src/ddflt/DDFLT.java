/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ddflt;

public class DDFLT {
    
    public static void main(String args[])
    {
        Login l=new Login();
        l.setVisible(true);
        l.setSize(470,415);
        l.setLocation(400,180);
        l.setResizable(false);
              
    }
}
