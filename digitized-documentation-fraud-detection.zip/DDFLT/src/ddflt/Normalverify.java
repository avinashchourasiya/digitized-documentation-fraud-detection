/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ddflt;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.File;
import java.util.Locale;
public class Normalverify extends javax.swing.JFrame {

    public Normalverify() {
        initComponents();
        this.setResizable(false);
        setIcon();
        
    }

    private void setIcon() {
         setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("DDFicon.png")));
     this.setTitle("Digitized Fraud Detecetion(DFD)");
    }
public class ProgressBar implements ActionListener{
public void actionPerformed(ActionEvent ae){
int n=prgbar.getValue();
if(n<100){
n++;
prgbar.setValue(n);
}
else{
    timer.stop();
    JOptionPane.showMessageDialog(null,"Valid");
}
}
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jlabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        prgbar = new javax.swing.JProgressBar();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(null);

        jlabel1.setBackground(new java.awt.Color(255, 255, 255));
        jlabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jlabel1.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(jlabel1);
        jlabel1.setBounds(23, 20, 411, 177);

        jButton1.setText("Verify");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(171, 203, 90, 30);
        getContentPane().add(prgbar);
        prgbar.setBounds(10, 250, 449, 41);

        jButton2.setText("Exit");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(354, 201, 80, 30);

        jButton3.setText("Browse");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(23, 201, 80, 30);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ddflt/home-img-iso.jpg"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 470, 300);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if(jlabel1.getIcon()==null){  
        JOptionPane.showMessageDialog(rootPane,"Please Upload Image");
        }
     
        else{
        timer.start();     
       
        Thread t  = new Thread(){
     
           // @Override
  public void run()
  {
   try{Thread.sleep(10000);}catch(Exception e){ e.printStackTrace();}
   aadharpage w=new aadharpage();
   w.setSize(500,337);
   
      w.setVisible(true);
   }     
   };
        t.start();
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
        timer=new Timer(100,new ProgressBar());
    }//GEN-LAST:event_formWindowOpened

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       System.exit(0);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
         JFileChooser choose = new JFileChooser();
       choose.setFileSelectionMode(JFileChooser.FILES_ONLY);
       int res;
        res = choose.showOpenDialog(Normalverify.this);
       
       if(res == JFileChooser.APPROVE_OPTION){
           File file = choose.getSelectedFile();
           
           ImageIcon image = new ImageIcon(file.getAbsolutePath());
           
           Rectangle rect = jlabel1.getBounds();
           
           Image scaledimage = image.getImage().getScaledInstance(rect.width,rect.height,Image.SCALE_DEFAULT);
           
           image = new ImageIcon(scaledimage);
           jlabel1.setIcon(image);
       }
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Normalverify.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Normalverify.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Normalverify.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Normalverify.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Normalverify().setVisible(true);
            }
        });
    }
    private Timer timer;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jlabel1;
    private javax.swing.JProgressBar prgbar;
    // End of variables declaration//GEN-END:variables
}
